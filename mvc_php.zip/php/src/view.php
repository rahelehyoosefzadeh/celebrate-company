<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>MVC PHP Sample</title>
</head>
<body>
        <h1>Hi</h1>
        <div><?php echo $page->getPrompt(); ?></div>
</body>
</html>

