<?php

namespace app\src;
use app\src\PageController;

/**
 * Description of route
 *
 * @author rah
 */
class route {
    public $path;
    public function __construct() {
        $this->path  = $_SERVER["REQUEST_URI"];        
    }
    public function parse() {
        $parts = explode('/', $this->path);
        $controllerObj = new PageController();
        switch ($parts[1]){
            case "":
                $prompt =  "I'm in the homepage";
                break;
            case "folder1":
                $prompt =  "I'm in folder1";
                break;
            case "folder2":
                $prompt =  "I'm in folder2";
                break;
            default:
                $prompt =  "Whooops! Not Found!";
        }
        $controllerObj->displayPage($prompt);
        return $prompt;
        
    }

}
