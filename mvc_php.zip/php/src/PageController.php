<?php
namespace app\src;

use app\src\model;
/**
 * Description of PageController
 * PageController class as it was required to flow the data(prompts) from/to the model and the view.
 * @author rah
 */

class PageController {
    public function displayPage($prompt){
        $page = new model();
        $page->setPrompt($prompt);
        require_once 'view.php';
        
    }
}
