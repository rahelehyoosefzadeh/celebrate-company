<?php
namespace app\src;
/**
 * Description of model
 * model Class for preparing data to flow into the pages
 * @author rah
 */


class model
{
    protected $prompt;
    public function getPrompt()
    {
        return $this->prompt;
    }
    public function setPrompt(string $prompt)
    {
        $this->prompt = $prompt;
    }
    //Just in case there is a need of crud
    public function create(array $data)
    {
    }
    public function read(int $id)
    {
    }
    public function update(int $id, array $data)
    {
    }
    public function delete(int $id)
    {
    }
}


?>