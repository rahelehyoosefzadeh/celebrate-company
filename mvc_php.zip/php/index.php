        <?php
       use app\src\route;
       require_once __DIR__."/vendor/autoload.php";
        
       
        $route  = new route();
        $prompt =  $route->parse();
        ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>MVC PHP Sample</title>
</head>
<body>

<h1>Just for the purpose of navigation into pages</h1>
    <ul>
        <li><a href="/" >Page1 - homepage</a></li>
        <li><a href="/folder1/" >Page2 - folder1</a></li>
        <li><a href="/folder2/" >Page3 - folder2</a></li>
    </ul>

</body>
</html>


